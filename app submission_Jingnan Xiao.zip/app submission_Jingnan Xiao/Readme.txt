A demo video is also in this folder. 

Environment: 
Frontend: React
Backend: Node.js
Database: MySQL
CodeEditor: VS code

How to use this app:
1. Open the folder "booking-app" with VS code.

2. In the terminal, input "cd booking-app-front", and use this terminal for React.

3. Input npm start to open the app in the browser.

4. Create another termial, input "cd booking-app-back", and use this terminal for Node.

5. Input node app.js to run the backend.

6. Open MySQL workbench.(Make sure the database instance is consistent with the MySQL connection in app.js)

7. In the website, input the name, email, and select date and time, click submit.If the input is not completed, there will be an error in the form saying you should enter all field.

8. Result:
  1) The input will display in a table under the form.
  2) The input will display in console of the browser.
  3) A database and a table are created in MySQL workbench if not present, and all the inputs are saved in the table.

