import React, { Component } from 'react';
import AddBooking from './components/AddBooking';

class App extends Component {
  render() { 
    return (
      <div>
        <AddBooking />
      </div>
    );
  }
} 
export default App;

