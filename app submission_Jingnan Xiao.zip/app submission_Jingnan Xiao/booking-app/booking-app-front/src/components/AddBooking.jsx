import React, { Component } from "react";
import DataTable from "./DataTable";

class AddBooking extends Component {
    // use React.createRef() to get data from DOM
    constructor(props) {
        super(props);         
        this.nameRef = React.createRef(); // for getting the name input from DOM
        this.emailRef = React.createRef(); // for getting the email input from DOM
        this.dateRef = React.createRef(); // for getting the date input from DOM
        this.timeRef = React.createRef(); // for getting the time input from DOM
    }

    // an initially empty array in the state to store the user input
    state = {
        inputs: []   
    };

    // after submit the form, save the user input into the array in the state and send the input to backend
    handleSubmit = (event) => {   
        event.preventDefault();   

        // get the user input from DOM
        const name = this.nameRef.current.value; 
        const email = this.emailRef.current.value; 
        const date = this.dateRef.current.value; 
        const time = this.timeRef.current.value; 
        
        // check whether the user input is completed
        if (name === '' || email === '' || date === '' || time === ''){ 
            const msg = document.querySelector('.msg');      
            msg.innerHTML = 'Please enter all fields.' // display an error message to users
            setTimeout(() => msg.innerHTML = '     ', 2000); //remove the error message after 3 sec
        } 

        // store user input into the array in the state and send the input to backend
        else {
            // clone the current data in the state
            const inputsTemp = [...this.state.inputs];  

            // store the user input as an element of the array in the state 
            const index = inputsTemp.length
            inputsTemp[index] = {id: index, name: name, email: email, date: date, time: time} 

            //display the current saved user input in Console
            console.log(inputsTemp);
            
            // Update the state
            this.setState({inputs : inputsTemp});  
            
            // send the input to backend (file app.js in ../booking-app-backend)
            const requestOptions = {
                method: "POST",
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(inputsTemp[inputsTemp.length - 1]) //every click only sent the new input item, not the whoe array
            }
            fetch('http://localhost:4000/post', requestOptions). //in backend file app.js, it should be app.listen(4000);
                then(response => console.log('successfully sent to the backend'));

            // clear the input fields for the next input
            this.nameRef.current.value = '';
            this.emailRef.current.value = '';
            this.dateRef.current.value = '';
            this.timeRef.current.value = '';
        }   
    } //end of handleSubmit()
    
    render() {
        return (        
            <div className="div-style">
                {/* box around the form*/}
                <fieldset className="box">   

                {/* a placeholder we can display some error message to the user*/}
                <div className="msg"></div> 

                {/* the input form, will execute handleSubmit() method after submitting the form */}               
                <form onSubmit={this.handleSubmit}>
                    {/* input full name*/}
                    <div className="name-email"> 
                    <label>Full Name</label>
                    <input type="text" ref = {this.nameRef} placeholder="Enter your full name" />
                    </div>

                    {/* input Email */}
                    <div className="name-email"> 
                    <label>Email</label>
                    <input type="email" ref = {this.emailRef} placeholder="Enter your Email here" />
                    </div>

                    {/* select date*/}
                    <div className="date">   
                    <label>Date</label>
                    <input type="date" ref = {this.dateRef}/>
                    </div>

                    {/* select time*/}
                    <div className="time">   
                    <label>Time</label>
                    <input type="time" ref = {this.timeRef}/>
                    </div>
                    
                    {/* submit button*/}
                    <input 
                    type="submit" 
                    className="btn btn-block"                    
                    />   
                    
                    {/* a table of user input displayed below the form*/}
                    <DataTable      
                        //set props for DataTable.jsx, save the user inputs in the props, so we can catch this props their and manipulate the user input there           
                        rows = {this.state.inputs} 
                    />            
                </form>
                </fieldset>
            </div>
        );
    } // end of Render()
} // end of class

export default AddBooking;
