import React, { Component } from 'react';

class TableRow extends Component {
    render() {          
        return (
            <tr >
                {/*  Catch the props set in DataTable.jsx, which passes the user input to here */}
                <td>{this.props.column1}</td>
                <td>{this.props.column2}</td>
                <td>{this.props.column3}</td>
                <td>{this.props.column4}</td>
        </tr>
        );
    }
}
 
export default TableRow;