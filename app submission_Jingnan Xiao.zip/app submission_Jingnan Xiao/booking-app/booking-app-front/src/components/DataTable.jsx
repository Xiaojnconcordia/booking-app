import React, { Component } from 'react';
import TableRow from './TableRow';
class DataTable extends Component {  
    render() { 
        return (
            <div className="div-style">                
                {/* a table to store user input */}
                <table className='table'>
                    <thead>
                        <tr>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Date</th>
                            <th>Time</th>
                        </tr>
                    </thead>                        
                    <tbody>
                        {/* Create the date rows of the table.*/}
                        {/* Catch the props set in AddBooking.jsx, which stores the user input */}
                        {this.props.rows.map( 
                            row => (<TableRow 
                                //set props for TableRow.jsx, so we can pass the user input catched above to TableRow.jsx     
                                key = {row.id} // need a key for each child in the list 
                                column1 = {row.name} 
                                column2 = {row.email}
                                column3 = {row.date} 
                                column4 = {row.time} 
                            />))
                        } 
                    </tbody>
                </table>
            </div>            
        );
    } // end of Render()
} // end of class
 
export default DataTable;