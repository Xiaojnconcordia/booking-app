//for receiving data from frontend
const express = require('express');
const app = express();
const cors = require("cors");
app.use(express.json());
app.use(cors());

// for saving data to the database
const mysql = require('mysql');
const connection = mysql.createConnection ({
    host: "localhost",
    user: "root",
    password: ""
});



// receive user input that are posted by frontend (file AddBooking.jsx in ../booking-app-front)
app.post("/post", (req, res) =>{
    console.log("Connected to React"); 
    console.log(req.body); // if the data is sent successfully from the front end, this req.body should be an object of the last user input
    res.send(req.body);

    const dataToDatabase = req.body;

    const databaseQuery = "CREATE DATABASE IF NOT EXISTS booking_records"; 
    connection.query(databaseQuery, function(err, result){
        if (err){
            console.log("Error occurred when creating database:", err);
        }
    });

    // use the new created database
    connection.changeUser({database: "booking_records"})

    // create a new table if not already present
    const tableQuery = "CREATE TABLE IF NOT EXISTS bookings (id INT NOT NULL AUTO_INCREMENT, full_name varchar(50), email varchar(50), date varchar(20), time varchar(20), PRIMARY KEY(id))";        
    connection.query(tableQuery, function(err, result){
        if (err){
            console.log("Error occurred when creating TABLE:", err);
        }            
    });
    
    // insert new submitted user input in to TABLE 
    const rowQuery = `INSERT INTO bookings (full_name, email, date, time) VALUES ('${dataToDatabase.name}', '${dataToDatabase.email}', '${dataToDatabase.date}', '${dataToDatabase.time}')`;        
    connection.query(rowQuery, function(err, result){
        if (err){
            console.log("Error occurred when inserting records:", err);
        }
    })  
    // connection.connect((err) => {
    //     if (err){        
    //         console.log("Error occurred when connecting to the database:", err);
    //     }   
    //     else {
    //         console.log("Connected to MySQL Server");

    //         // create a new database if not already present

    //     }
    // }); //end of connection.connect
    //connection.end();
}); //end of app.post

app.listen(4000);